import boto3
import time

# Initialize EC2 client
ec2_client = boto3.client('ec2', region_name='ap-south-1')


def get_ec2_instance_public_dns(asg_name):
    # Wait for a few seconds to give the instance time to launch
    print("Waiting for instance to launch...")
    time.sleep(30)  # Wait for 30 seconds (you may adjust this)

    # Get list of all instances
    response = ec2_client.describe_instances()

    # Loop through reservations and instances
    for reservation in response['Reservations']:
        for instance in reservation['Instances']:
            # Check if the instance belongs to the correct Auto Scaling Group
            for tag in instance.get('Tags', []):
                if tag['Key'] == 'aws:autoscaling:groupName' and tag['Value'] == asg_name:
                    # Ensure the instance is in running state
                    if instance['State']['Name'] == 'running':
                        public_dns = instance.get('PublicDnsName', 'N/A')
                        print(f"Instance ID: {instance['InstanceId']}, Public DNS: {public_dns}")
                        return public_dns

    return None


# Name of your Auto Scaling Group
asg_name = 'ASGassignment5on'

# Get public DNS of the instance
public_dns = get_ec2_instance_public_dns(asg_name)

if public_dns:
    print(f"Access your static website at: http://{public_dns}")
else:
    print("No running instance found for the Auto Scaling Group.")
