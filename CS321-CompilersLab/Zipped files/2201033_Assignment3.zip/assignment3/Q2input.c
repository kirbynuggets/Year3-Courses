# include <stdio.h>

int main() {
  int count = 0;
  float value123 = 3.14;
  char str = "Hello";
  if (value123 > 0) {
    printf("Positive\n");
  }
  123abc = 5; // Invalid identifier (not to be considered as per study.)
}