int a = 48;
int b = 18;
while (b != 0) {
    int t = b;
    b = a % b;
    a = t;
}