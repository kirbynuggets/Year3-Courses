{
    int a = 3;
    int b = 4;
    int c = 5;
    int s = (a + b + c) / 2;
    int area = s * (s - a) * (s - b) * (s - c);
}