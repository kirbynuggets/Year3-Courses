{
int p = 1000;
int r = 5;
int t = 2;
int si = p * r * t / 100;
int amount=p+si;
}