
public class Q1input {

    

    public static void main(String[] args) {
        System.out.println("Hello, World!"); 

        
        for (int i = 0; i < 5; i++) {
            System.out.println("Iteration: " + i); 
        }

        
        int x = 10; 

        
        if (x > 5) {
            System.out.println("x is greater than 5");
        }
    }
}
