

 public class Q2input {
    public static void main(String[] args) {
        System.out.println("Starting program..."); 

        int a = 10; 
        int b = 20; 

         int sum = a + b; 

        System.out.println("Sum: " + sum); 

        
        if (sum > 20) { 
            System.out.println("Sum is greater than 20"); 
        } else {
            System.out.println("Sum is 20 or less"); 
        }
        
        System.out.println("End of program"); 

        String str = "Text with comment inside  here"; 

        
    }
}
